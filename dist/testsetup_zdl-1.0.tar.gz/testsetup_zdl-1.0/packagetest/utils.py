def v1(a):
    print(a,1)

def v2(a):
    print(a,2)

def v3(a):
    print(a,3)
def v4(a):
    print(a,4)
def v5(a):
    print(a,5)
def v6(a):
    print(a,6)
def v7(a):
    print(a,7)

def v8(a):
    print(8888)